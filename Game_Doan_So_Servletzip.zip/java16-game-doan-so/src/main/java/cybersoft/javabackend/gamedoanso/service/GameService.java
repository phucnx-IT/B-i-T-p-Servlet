package cybersoft.javabackend.gamedoanso.service;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = { "/game-service" })
public class GameService extends HttpServlet {
	int randomNumber = (int) (Math.random() * 1000 + 1);

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		resp.setCharacterEncoding("UTF-8");
		req.setCharacterEncoding("UTF-8");
		PrintWriter writer = resp.getWriter();
		String randomNumber = req.getParameter("randomNumber");
		String userName = req.getParameter("username");
		String count = req.getParameter("count");
		int soBiMat = Integer.parseInt(randomNumber);
		int demSoLanDoan = Integer.parseInt(count);
		demSoLanDoan++;
		writer.print("<form action='/java16-game-doan-so/game-servlet' method='post' style='text-align:center'>");
		writer.print("<h2>Nhập số dự đoán từ 1-1000</h2>");
		writer.print("<input type='text' name='randomNumber'value='" + soBiMat + "' style='display:none'>");
		writer.print("<input type='text' name='count'value='" + demSoLanDoan + "' style='display:none'>");
		writer.print("<input type='text' name='username'value='" + userName + "' style='display:none'>");
		writer.print("<input type='text' name='number'required pattern='[0-9]+'>");
		writer.print("<input type='submit' value='Đoán'>");
		writer.print("</form>");

	}

}
